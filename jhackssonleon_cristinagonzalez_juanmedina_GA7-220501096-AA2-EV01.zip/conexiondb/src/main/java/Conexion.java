import java.sql.*;
public class Conexion {
    
    public static void main(String[] args) {
        // Configuración de la conexión a la base de datos
        String url = "jdbc:mysql://localhost:3306/controldeplagasbd";
        String usuario = "root";
        String contrasena = "1234";

        Connection connection = null;

        try {
            // Paso 1: Registrar el controlador JDBC
            Class.forName("com.mysql.cj.jdbc.Driver");

            // Paso 2: Establecer la conexión con la base de datos
            connection = DriverManager.getConnection(url, usuario, contrasena);

            // Si la conexión se establece con éxito, mostramos un mensaje de conexión exitosa
            System.out.println("Conexión establecida correctamente.");
        } catch (ClassNotFoundException e) {
            // Error si no se encuentra el controlador JDBC
            System.out.println("Error: No se encontró el controlador JDBC.");
            e.printStackTrace();
        } catch (SQLException e) {
            // Error si ocurre alguna excepción SQL durante la conexión
            System.out.println("Error al establecer la conexión con la base de datos.");
            e.printStackTrace();
        } finally {
            // Cerrar la conexión y liberar recursos
            if (connection != null) {
                try {
                    connection.close();
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            }
        }
    }
}

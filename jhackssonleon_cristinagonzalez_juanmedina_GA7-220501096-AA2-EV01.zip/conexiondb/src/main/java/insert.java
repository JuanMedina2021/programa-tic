import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.ArrayList;
public class insert{

    public static void main(String[] args) {
         // estan las clases
         ArrayList<String> classes = new ArrayList<String>();
         classes.add("usuario");
         classes.add("enfermedades");
         classes.add("productor_de_panela");
         classes.add("cana_de_azucar");
        // Información de conexión a la base de datos
        String url = "jdbc:mysql://localhost:3306/controldeplagasbd";
        String usuario = "root";
        String contrasenna = "1234";

        // Datos a insertar en la tabla Usuario
        int idUsuario = 100;
        String nombre = "Juan";
        String contrasena = "1234";
        // Datos para la tabla enfermedades
        String fecha_inicio = "2023-06-17";
        String fecha_final = "2023-08-17";
        int afectacion_produccion = 25;
        String nombre_enfermedad = "platano";
        int id_reporte_enfermedades = 16;
        //  Datos para la tabla productor de panela
        int id_panela = 87;
        String nombre_ingenio = "santa barbara";
        String calidad_panela = "alta";
        // Datos para la tabla caña de azucar 
        int producido = 129;
        String variedad_de_cana=" CP 72" ;
        String toneladas_exportadas = "6 toneladas";
        int id_cana = 338;
        // Sentecias para insertar en SQl
        String sqlusuario = "INSERT INTO usuario VALUES ("+ idUsuario + ", '" + nombre + "','" + contrasena + "')";
        String sqlEnfermedades = "INSERT INTO enfermedades VALUES ('"+ fecha_inicio +"','"+ fecha_final +"',"+ afectacion_produccion + ",'"+ nombre_enfermedad +"',"+ id_reporte_enfermedades +")";
        String sqlProductordepanela = "INSERT INTO productor_de_panela VALUES('"+ nombre_ingenio+"',"+id_panela +",'"+ calidad_panela +"')";
        String sqlcanadeazucar = "INSERT INTO cana_de_azucar VALUES("+producido +",'" + variedad_de_cana + "', '" +  toneladas_exportadas + "'," + id_cana +")";

        // Establecer la conexión
        try (Connection conn = DriverManager.getConnection(url, usuario, contrasenna)) {
            // Sentencia SQL INSERT
            PreparedStatement statement = conn.prepareStatement(sqlcanadeazucar);
            // Ejecutar la sentencia INSERT
            int filasInsertadas = statement.executeUpdate();

            if (filasInsertadas > 0) {
                System.out.println("Inserción exitosa");
            } else {
                System.out.println("No se pudo insertar el registro");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}

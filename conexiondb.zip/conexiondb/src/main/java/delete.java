import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class delete {

    public static void main(String[] args) {
        // Información de conexión a la base de datos
        String url = "jdbc:mysql://localhost:3306/controldeplagasbd";
        String usuario = "root";
        String contraseña = "1234";

        // ID del registro a eliminar
        int idUsuario= 1;
        int id_reporte_enfermedades = 1;
        int id_panela = 1;
        int id_cana = 2;
         // Sentencia SQL DELETE
         String sqltablausuario = "DELETE FROM usuario WHERE idUsuario = " + idUsuario ;
         String sqltablaenfermedades = "DELETE FROM enfermedades WHERE id_reporte_enfermedades = "+ id_reporte_enfermedades;
         String sqltablaproductordepanela= "DELETE FROM productor_de_panela WHERE id_panela = "+ id_panela;
         String sqltablacanadeazucar= "DELETE FROM cana_de_azucar WHERE id_caña = " + id_cana;
        // Establecer la conexión
        try (Connection conn = DriverManager.getConnection(url, usuario, contraseña)) {
            PreparedStatement statement = conn.prepareStatement(sqltablacanadeazucar);

            // Establecer el valor del parámetro
           /*  statement.setInt(1, idUsuario);
            statement.setInt(1, id_reporte_enfermedades);
            statement.setInt(1, id_panela);
            statement.setInt(1, id_cana);*/

            // Ejecutar la sentencia DELETE
            int filasEliminadas = statement.executeUpdate();

            if (filasEliminadas > 0) {
                System.out.println("Eliminación exitosa");
            } else {
                System.out.println("No se encontró el registro a eliminar");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}

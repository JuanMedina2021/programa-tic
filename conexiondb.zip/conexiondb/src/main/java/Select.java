import java.sql.*;
import java.util.ArrayList;
public class Select {
    public static void main(String[] args) {
        String url = "jdbc:mysql://localhost:3306/controldeplagasbd";
        String usuario = "root";
        String contrasena = "1234";
        // estan las clases
        ArrayList<String> classes = new ArrayList<String>();
        classes.add("usuario");
        classes.add("enfermedades");
        classes.add("productor_de_panela");
        classes.add("cana_de_azucar");
        System.out.println(classes.get(0));
        try (Connection connection = DriverManager.getConnection(url, usuario, contrasena);
        PreparedStatement statement = connection.prepareStatement("SELECT * FROM " + classes.get(1));
       ResultSet resultSet = statement.executeQuery()) {
       // Recorrer los resultados
       String st = statement.toString();
       if(st.contains(classes.get(0))){
        while (resultSet.next()) {
            // Obtener los valores de las columnas por nombre o índice
            int idusuario = resultSet.getInt("idUsuario");
            String nombre = resultSet.getString("nombre");
            String contrasenna = resultSet.getString("contraseña");
            // Hacer algo con los valores obtenidos
            System.out.println("IDUsuario: " + idusuario + ", Nombre: " + nombre + ", contrasena: " + contrasenna + " ");
        }
       }
       else if(st.contains(classes.get(1))){
        while (resultSet.next()){
            Date fecha_inicio = resultSet.getDate("fecha_inicio".toString());
            Date fecha_final = resultSet.getDate("fecha_final".toString());
            int afectacion_produccion = resultSet.getInt("afectacion_produccion");
            String nombre_enfermedad = resultSet.getString("nombre_enfermedad");
            int id_reporte_enfermedades = resultSet.getInt("id_reporte_enfermedades");
            System.out.println("fecha de inicio: " + fecha_inicio +", fecha final: "+ fecha_final + ", produccion afectada: " + afectacion_produccion);
            System.out.println("nombre de enfermedad: " + nombre_enfermedad  + ", enfermedades: " + id_reporte_enfermedades);
        }
       }
       else if(st.contains(classes.get(2))){
        while(resultSet.next()){
            String nombre_ingenio = resultSet.getString("nombre_ingenio");
            int id_panela = resultSet.getInt("id_panela");
            String calidad_panela = resultSet.getString("calidad_panela");
            System.out.println("Nombre del ingenio: "+ nombre_ingenio +", Id de la panela: "+ id_panela);
            System.out.println("calidad de la panela: " + calidad_panela);
        }
       }
       else if(st.contains(classes.get(3))){
        while(resultSet.next()) {
        int producido = resultSet.getInt("producido");
        String variedad_de_cana = resultSet.getString("variedad_de_caña");
        String toneladas_exportadas = resultSet.getString("toneladas_exportadas");
        int id_cana = resultSet.getInt("id_cana");
        System.out.println("Producido: "+ producido + " Variedad de caña : " + variedad_de_cana);
        System.out.println(" Toneladas Exportadas : " + toneladas_exportadas);
        System.out.println( "Id de la caña "+ id_cana);
        }
       }
   } catch (SQLException e) {
       System.out.println("Error al ejecutar la consulta SELECT.");
       e.printStackTrace();
   }

}
    }


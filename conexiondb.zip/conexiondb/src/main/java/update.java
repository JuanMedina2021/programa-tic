import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class update{

    public static void main(String[] args) {
        // Información de conexión a la base de datos
        String url = "jdbc:mysql://localhost:3306/controldeplagasbd";
        String usuario = "root";
        String contrasenna = "1234";
     //datos para tabla usuario
        int idUsuario = 100;
        String nombre = "Pedro";
        String contrasena = "12345678";
        // Datos para la tabla enfermedades
        String fecha_inicio = "2023-06-17";
        String fecha_final = "2023-08-17";
        int afectacion_produccion = 25;
        String nombre_enfermedad = "platano";
        int id_reporte_enfermedades = 16;
        //  Datos para la tabla productor de panela
        int id_panela = 87;
        String nombre_ingenio = "santa barbara";
        String calidad_panela = "alta";
        // Datos para la tabla caña de azucar 
        int producido = 129;
        String variedad_de_cana=" CP 72" ;
        String toneladas_exportadas = "6 toneladas";
        int id_cana = 338;    

        // Establecer la conexión
        try (Connection conn = DriverManager.getConnection(url, usuario, contrasenna)) {
            // Sentencia SQL UPDATE Usuario
            String sqlUsuario = "UPDATE usuario SET nombre = '"+ nombre +"', contraseña='"+ contrasena + "' WHERE idUsuario = "+ idUsuario;
             
            
              //setencia SQL  UPDATE enfermedades
              String sqlEnfermedades = "UPDATE enfermedades SET fecha_inicio = '"+ fecha_inicio + "' SET fecha_final = '"+ fecha_final + "' SET afectacion_produccion = " + afectacion_produccion + " SET nombre_enfermedad = '" + nombre_enfermedad+ "' " +"WHERE id_reporte_enfermedades ="+ id_reporte_enfermedades;   
             
            //sentencia SQL UPDATE productor de panela
            String sqlproductor_de_panela = "UPDATE productor_de_panela SET nombre_ingenio = '"+ nombre_ingenio + "' SET calidad_panela = '"+ calidad_panela + "" +"WHERE id_panela ="+ id_panela; 
             //sentencia SQL UPTADE caña de azucar
             String sqlCana_de_azucar  = "UPDATE cana_de_azucar SET producido = '"+ producido + "' SET variedad_de_cana = '"+ variedad_de_cana + "' SET toneladas_exportadas = " + toneladas_exportadas + "WHERE id_cana ="+ id_cana;
            PreparedStatement statement = conn.prepareStatement(sqlUsuario);

            // Ejecutar la sentencia UPDATE
            int filasActualizadas = statement.executeUpdate();

            if (filasActualizadas > 0) {
                System.out.println("Actualización exitosa");
            } else {
                System.out.println("No se encontró el registro a actualizar");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}

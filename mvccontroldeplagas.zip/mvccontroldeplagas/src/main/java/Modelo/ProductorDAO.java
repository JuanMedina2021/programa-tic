package Modelo;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;
public class ProductorDAO {
     public List selectProductor(){
         List<Productor_de_panela> listaProductor = new ArrayList<>();
       try {
            // Establecer la conexión con la base de datos

            Connection conn = DriverManager.getConnection(Conexionurl.url, Conexionurl.usuario, Conexionurl.contrasena);
            String query = "SELECT * FROM productor_de_panela;";
            Statement statement = conn.createStatement();
            ResultSet resultSet = statement.executeQuery(query);
            while(resultSet.next()){
               String nombre_ingenio = resultSet.getString("nombre_ingenio");
               int id_panela = resultSet.getInt("id_panela");
               String calidad_panela = resultSet.getString("calidad_panela");
               Productor_de_panela productor_de_panela = new Productor_de_panela();
               productor_de_panela.setNombre_ingenio(nombre_ingenio);
               productor_de_panela.setIdPanela(id_panela);
               productor_de_panela.setCalidad_panela(calidad_panela);
               listaProductor.add(productor_de_panela);
               System.out.println("nombre_ingenio: " + nombre_ingenio);
               System.out.println("id_panela: " + id_panela);
               System.out.println("calidad_panela: " + calidad_panela);
               System.out.println("---------------");
            }
            resultSet.close();
            statement.close();
            conn.close();
             }
             catch(SQLException e){
                e.printStackTrace();
                System.out.println("Error al ejecutar la consulta SELECT.");
             }
       return listaProductor;
     }
 public int insertProductor_de_panela(Productor_de_panela productor_de_panela){
        try {
            Connection conn = DriverManager.getConnection(Conexionurl.url, Conexionurl.usuario, Conexionurl.contrasena);
            String query = "INSERT INTO productor_de_panela(nombre_ingenio,id_panela,calidad_panela) VALUES(?,?,?)";
            PreparedStatement statement = conn.prepareStatement(query);
            statement.setString(1, productor_de_panela.getNombre_ingenio());
            statement.setInt(2, productor_de_panela.getidPanela());
            statement.setString(3, productor_de_panela.getCalidad_panela());
            statement.executeUpdate();
            System.out.println("nombre_ingenio: " + productor_de_panela.getNombre_ingenio());
            System.out.println("id_panela: " + productor_de_panela.getidPanela());
            System.out.println("calidad_panela : " + productor_de_panela.getCalidad_panela());
            System.out.println("---------------");
            System.out.println("Insercion Exitosa");
            statement.close();
            conn.close();
            return 1;
        }
        catch(SQLException e){
            System.out.println("Error al ejecutar la consulta INSERT.");
            e.printStackTrace();
            return 0;
        }
    }
 public int updateProductor_de_panela(Productor_de_panela productor_de_panela){
    try {
        Connection conn = DriverManager.getConnection(Conexionurl.url, Conexionurl.usuario, Conexionurl.contrasena);
        String query = "UPDATE productor_de_panela SET nombre_ingenio = ?, calidad_panela  = ? WHERE id_panela = ? ;";
        PreparedStatement statement = conn.prepareStatement(query);
        statement.setString(1, productor_de_panela.getNombre_ingenio());
        statement.setString(2, productor_de_panela.getCalidad_panela());
        statement.setInt(3, productor_de_panela.getidPanela());
        int filas = statement.executeUpdate();
        if (filas > 0) {
            System.out.println("idPanela: " + productor_de_panela.getidPanela());
            System.out.println("nombre_ingenio: " + productor_de_panela.getNombre_ingenio());
            System.out.println("calidad_panela : " + productor_de_panela.getCalidad_panela());
            System.out.println("---------------");
            System.out.println("Actualización Exitosa");
        } else {
            System.out.println("No se encontró el registro a actualizar");
        }
        statement.close();
        conn.close();
        return 1;
    } catch (SQLException e) {
        e.printStackTrace();
        // TODO: handle exception
        return 0;
    }
    }

public void deleteProductor_de_panela(Productor_de_panela productor_de_panela, int id_panela){
    String query = "DELETE FROM productor_de_panela WHERE id_Panela = "+ id_panela;    
    try {
            Connection conn = DriverManager.getConnection(Conexionurl.url, Conexionurl.usuario, Conexionurl.contrasena);
            PreparedStatement statement = conn.prepareStatement(query);
            statement.setInt(1, productor_de_panela.getidPanela());
            statement.executeUpdate();
            System.out.println("Eliminación Exitosa de Panela");
            System.out.println("---------------");
            statement.close();
            conn.close();
        } catch (Exception e) {
            System.out.println("Error al ejecutar DELETE");
            e.printStackTrace();
            // TODO: handle exception
        }
    }


  public static void main(String[] args) {
        Productor_de_panela  productor_de_panela = new Productor_de_panela("san jorge I", "alta");
        ProductorDAO  productorDAO = new  ProductorDAO();
        //usuarioDAO.updateUsuario(usuario);
        productorDAO.selectProductor();
        
    }


}

package Modelo;

public class Usuario {
    private int idUsuario;
    private String nombre;
    private String contrasena;
    public Usuario(int idUsuario,String nombre,String contrasena){
        this.idUsuario = idUsuario;
        this.nombre = nombre;
        this.contrasena = contrasena;
    }
    public Usuario(){
        
    }
    public void setIdUsuario(int idUsuario){
        this.idUsuario = idUsuario;
    }
    public void setNombre(String nombre) {
        this.nombre = nombre;
    }
    public void setContrasena(String contrasena) {
        this.contrasena = contrasena;
    }
    public int getIdUsuario(){
        return idUsuario;
    }
    public String getNombre() {
        return nombre;
    }
    public String getContrasena() {
        return contrasena;
    }
    
}

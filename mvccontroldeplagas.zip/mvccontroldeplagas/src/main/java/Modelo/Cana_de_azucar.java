package Modelo;
public class Cana_de_azucar {
    private int producido;
    private String variedad_de_cana;
    private String toneladas_exportadas;
    private int idcana;
    public Cana_de_azucar(int producido,String variedad_de_cana, String toneladas_exportadas) {
        this.producido = producido;
        this.variedad_de_cana = variedad_de_cana;
        this.toneladas_exportadas = toneladas_exportadas;
    }
    public Cana_de_azucar(){
        
    }
    public void setProducido(int producido) {
        this.producido = producido;
    }
    public void setVariedad_de_cana(String variedad_de_cana) {
        this.variedad_de_cana = variedad_de_cana;
    }
    public void setToneladas_exportadas(String toneladas_exportadas) {
        this.toneladas_exportadas = toneladas_exportadas;
    }
      public void setIdcana(int idcana) {
        this.idcana = idcana;
    }
    public int getProducido() {
        return producido;
    }
    public String getVariedad_de_cana() {
        return variedad_de_cana;
    }
    public String getToneladas_exportadas() {
        return toneladas_exportadas;
    }
    public int getIdcana() {
        return idcana;
    }
    
}

package Modelo;
public class Enfermedades {
    private String fecha_inicio;
    private String fecha_final;
    private int afectacion_produccion;
    private String nombre_enfermedad;
    private int id_reporte_enfermedades;
    public Enfermedades(String fecha_inicio, String fecha_final, int afectacion_produccion, String nombre_enfermedad) {
        this.fecha_inicio = fecha_inicio;
        this.fecha_final = fecha_final;
        this.afectacion_produccion = afectacion_produccion;
        this.nombre_enfermedad = nombre_enfermedad;
    }
    public Enfermedades(){
        
    }
    public void setFecha_Inicio(String fecha_inicio) {
        this.fecha_inicio = fecha_inicio;
    }
    public void setFecha_Final(String fecha_final) {
        this.fecha_final = fecha_final;
    }
    public void setAfectacion_Produccion(int afectacion_produccion) {
        this.afectacion_produccion = afectacion_produccion;
    }
    public void setNombre_Enfermedad(String nombre_enfermedad) {
        this.nombre_enfermedad = nombre_enfermedad;
    }
    public void setId_Reporte_Enfermedades(int id_reporte_enfermedades) {
        this.id_reporte_enfermedades = id_reporte_enfermedades;
    }
    public String getFecha_Inicio() {
        return fecha_inicio;
    }
    public String getFecha_Final() {
        return fecha_final;
    }
    public int getAfectacionProduccion() {
    return afectacion_produccion;
    }
    public String getNombre_Enfermedad(){
        return nombre_enfermedad;
    }
    public int getId_Reporte_Enfermedades(){
        return id_reporte_enfermedades;
    }
}

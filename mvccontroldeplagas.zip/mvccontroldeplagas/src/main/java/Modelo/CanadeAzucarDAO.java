package Modelo;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;


public class CanadeAzucarDAO {
    
    public List selectCana(){
        // Lista para recoger la entidad sql
        List<Cana_de_azucar> listacda = new ArrayList<>();
       try {
            // Establecer la conexión con la base de datos
            // ejecuta la consulta
            Connection conn = DriverManager.getConnection(Conexionurl.url, Conexionurl.usuario, Conexionurl.contrasena);
            String query = "SELECT * FROM cana_de_azucar ;";
            Statement statement = conn.createStatement();
            ResultSet resultSet = statement.executeQuery(query);
            while(resultSet.next()){
               Cana_de_azucar cdea = new Cana_de_azucar(); 
               cdea.setProducido(resultSet.getInt(1));
               cdea.setVariedad_de_cana(resultSet.getString(2));
               cdea.setToneladas_exportadas(resultSet.getString(3));
               cdea.setIdcana(resultSet.getInt(4));
               listacda.add(cdea);
               System.out.println("producido: " + cdea.getProducido());
               System.out.println("variedad_de_caña: " + cdea.getVariedad_de_cana());
               System.out.println("toneladas_exportadas: " + cdea.getToneladas_exportadas());
               System.out.println("id_caña: " + cdea.getIdcana());
               System.out.println("---------------");         
            }
            resultSet.close();
            statement.close();
            conn.close();
        }

       catch(SQLException e){
        System.out.println("Error al ejecutar la consulta SELECT.");
        e.printStackTrace();
       }
       return listacda;
    }
    public int insertCana(Cana_de_azucar cana_de_azucar){
        try {
            Connection conn = DriverManager.getConnection(Conexionurl.url, Conexionurl.usuario, Conexionurl.contrasena);
            String query = "INSERT INTO cana_de_azucar(producido,variedad_de_caña,toneladas_exportadas) VALUES(?,?,?)";
            PreparedStatement statement = conn.prepareStatement(query);
            statement.setInt(1, cana_de_azucar.getProducido());
            statement.setString(2, cana_de_azucar.getVariedad_de_cana());
            statement.setString(3, cana_de_azucar.getToneladas_exportadas());
            statement.executeUpdate();
            System.out.println("producido: " + cana_de_azucar.getProducido());
            System.out.println("variedad_de_caña: " + cana_de_azucar.getVariedad_de_cana());
            System.out.println("toneladas_exportadas: " + cana_de_azucar.getToneladas_exportadas());
            System.out.println("---------------");
            System.out.println("Insercion Exitosa");
            statement.close();
            conn.close();
            return 1;
        }
        catch(SQLException e){
            System.out.println("Error al ejecutar la consulta INSERT.");
            e.printStackTrace();
            return 0;
        }
    }
    public int updateCana(Cana_de_azucar cana_de_azucar){
    try {
        Connection conn = DriverManager.getConnection(Conexionurl.url, Conexionurl.usuario, Conexionurl.contrasena);
        String query = "UPDATE cana_de_azucar SET producido = ?,variedad_de_caña = ?,toneladas_exportadas = ? WHERE id_caña = ?;";
        PreparedStatement statement = conn.prepareStatement(query);
        statement.setInt(1, cana_de_azucar.getProducido());
        statement.setString(2, cana_de_azucar.getVariedad_de_cana());
        statement.setString(3, cana_de_azucar.getToneladas_exportadas());
        statement.setInt(4, cana_de_azucar.getIdcana());
        int filas = statement.executeUpdate();
        if (filas > 0) {
            System.out.println("producido: " + cana_de_azucar.getProducido());
            System.out.println("variedad_de_caña: " + cana_de_azucar.getVariedad_de_cana());
            System.out.println("toneladas_exportadas: " + cana_de_azucar.getToneladas_exportadas());
            System.out.println("id_caña: " + cana_de_azucar.getIdcana());
            System.out.println("---------------");
            System.out.println("Actualización Exitosa");
        } else {
            System.out.println("No se encontró el registro a actualizar");
        }
        statement.close();
        conn.close();
    } catch (SQLException e) {
        e.printStackTrace();
        // TODO: handle exception
    }
    return 1;
    }
    public void deleteCana(Cana_de_azucar cana_de_azucar, int idcana){
        String query = "DELETE FROM cana_de_azucar WHERE id_caña = " + idcana;
        try {
            Connection conn = DriverManager.getConnection(Conexionurl.url, Conexionurl.usuario, Conexionurl.contrasena);
            PreparedStatement statement = conn.prepareStatement(query);
            statement.executeUpdate();
            System.out.println("Eliminación Exitosa de Informacion de Caña de Azucar");
            System.out.println("---------------");
            statement.close();
            conn.close();
        } catch (Exception e) {
            System.out.println("Error al ejecutar DELETE");
            e.printStackTrace();
            // TODO: handle exception
        }
    }
    public static void main(String[] args) {
        Cana_de_azucar cana_de_azucar = new Cana_de_azucar(188,"variedad255","20021");
        CanadeAzucarDAO canadeAzucarDAO = new CanadeAzucarDAO();
        canadeAzucarDAO.selectCana();
    }
}

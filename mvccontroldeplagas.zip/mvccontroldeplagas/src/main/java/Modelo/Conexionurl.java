package Modelo;

public class Conexionurl {
    public static String url = "jdbc:mysql://localhost:3306/controldeplagasbd";
    public static String usuario = "root";
    public static String contrasena = "1234";
}

package Modelo;
public class Productor_de_panela {
    private String nombre_ingenio;
    private int idpanela;
    private String calidad_panela;
public Productor_de_panela( String nombre_ingenio, String calidad_panela){
    this.nombre_ingenio = nombre_ingenio;
    this.calidad_panela = calidad_panela;
}
public Productor_de_panela(){}
public void setIdPanela( int idpanela){
  this.idpanela = idpanela;
}
public void setNombre_ingenio(String nombre_ingenio){
  this.nombre_ingenio = nombre_ingenio;
}
public void setCalidad_panela (String calidad_panela){
this.calidad_panela =calidad_panela;
}

public String getNombre_ingenio(){
return nombre_ingenio;
}

public int getidPanela(){
return idpanela;
}

public String getCalidad_panela(){
return calidad_panela;
}
}
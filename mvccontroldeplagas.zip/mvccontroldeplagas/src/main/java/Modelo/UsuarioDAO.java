package Modelo;
import java.sql.*;
public class UsuarioDAO {
    
     public void selectUsuario(){
       try {
            // Establecer la conexión con la base de datos

            Connection conn = DriverManager.getConnection(Conexionurl.url, Conexionurl.usuario, Conexionurl.contrasena);
            String query = "SELECT * FROM usuario ;";
            Statement statement = conn.createStatement();
            ResultSet resultSet = statement.executeQuery(query);
            while(resultSet.next()){
               int id_usuario = resultSet.getInt("idUsuario");
               String nombre  = resultSet.getString("nombre");
               String contrasena = resultSet.getString("contraseña");
               System.out.println("id_usuario: " + id_usuario);
               System.out.println("nombre: " + nombre);
               System.out.println("contrasena: " + contrasena );
               System.out.println("---------------");
            }
            resultSet.close();
            statement.close();
            conn.close();
             }
             catch(SQLException e){
                e.printStackTrace();
                System.out.println("Error al ejecutar la consulta SELECT.");
             }
     }

    /**
     *
     * @param usuario
     */
    public void insertUsuario(Usuario usuario){
        
        try {
            Connection conn = DriverManager.getConnection(Conexionurl.url, Conexionurl.usuario, Conexionurl.contrasena);
            String query = "INSERT INTO usuario(nombre,contraseña) VALUES(?,?)";
            PreparedStatement statement = conn.prepareStatement(query);
            statement.setString(1, usuario.getNombre());
            statement.setString(2, usuario.getContrasena());
            statement.executeUpdate();
            System.out.println("nombre: " + usuario.getNombre());
            System.out.println("contrasena : " + usuario.getContrasena());
            System.out.println("---------------");
            System.out.println("Insercion Exitosa");
            statement.close();
            conn.close();
        }
        catch(SQLException e){
            System.out.println("Error al ejecutar la consulta INSERT.");
            e.printStackTrace();
        }
    }

    public void updateUsuario(Usuario usuario){
    try {
        Connection conn = DriverManager.getConnection(Conexionurl.url, Conexionurl.usuario, Conexionurl.contrasena);
        String query = "UPDATE usuario SET nombre = ?, contraseña  = ? WHERE idUsuario = ?;";
        PreparedStatement statement = conn.prepareStatement(query);
        statement.setString(1, usuario.getNombre());
        statement.setString(2, usuario.getContrasena());
        statement.setInt(3, usuario.getIdUsuario());
        int filas = statement.executeUpdate();
        if (filas > 0) {
            System.out.println("idUsuario: " + usuario.getIdUsuario());
            System.out.println("nombre: " + usuario.getNombre());
            System.out.println("contrasena : " + usuario.getContrasena());
            System.out.println("---------------");
            System.out.println("Actualización Exitosa");
        } else {
            System.out.println("No se encontró el registro a actualizar");
        }
        statement.close();
        conn.close();
        
    } catch (SQLException e) {
        e.printStackTrace();
        // TODO: handle exception
    }
    }
 public void deleteUsuario(Usuario usuario){
        try {
            Connection conn = DriverManager.getConnection(Conexionurl.url, Conexionurl.usuario, Conexionurl.contrasena);
            String query = "DELETE FROM usuario WHERE idUsuario = ?;";
            PreparedStatement statement = conn.prepareStatement(query);
            statement.setInt(1, usuario.getIdUsuario());
            statement.executeUpdate();
            System.out.println("Eliminación Exitosa de Usuario");
            System.out.println("---------------");
            statement.close();
            conn.close();
        } catch (Exception e) {
            System.out.println("Error al ejecutar DELETE");
            e.printStackTrace();
            // TODO: handle exception
        }
    }
    public static void main(String[] args) {
        //Usuario usuario = new Usuario(10,"crtistina@gmail.com","juanmecnico");
        UsuarioDAO  usuarioDAO = new  UsuarioDAO();
        usuarioDAO.selectUsuario();
    }
}

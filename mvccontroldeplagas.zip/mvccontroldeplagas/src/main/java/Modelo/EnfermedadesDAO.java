package Modelo;
import java.sql.*;
import java.util.List;
import java.util.ArrayList;
public class EnfermedadesDAO {
    
    public List selectEnfermedades() {
        List<Enfermedades> listaenf = new ArrayList<>();
        try {
            Connection conn = DriverManager.getConnection(Conexionurl.url, Conexionurl.usuario, Conexionurl.contrasena);
            String query = "SELECT * FROM enfermedades ;";
            Statement statement = conn.createStatement();
            ResultSet resultSet = statement.executeQuery(query);
            while(resultSet.next()){
                String fecha_inicio = resultSet.getString("fecha_inicio");
                String fecha_final = resultSet.getString("fecha_final");
                int afectacion_produccion = resultSet.getInt("afectacion_produccion");
                String nombre_enfermedades = resultSet.getString("nombre_enfermedad");
                int id_reporte_enfermedades = resultSet.getInt("id_reporte_enfermedades");
                Enfermedades enfermedades = new Enfermedades();
                enfermedades.setFecha_Inicio(fecha_inicio);
                enfermedades.setFecha_Final(fecha_final);
                enfermedades.setAfectacion_Produccion(afectacion_produccion);
                enfermedades.setNombre_Enfermedad(nombre_enfermedades);
                enfermedades.setId_Reporte_Enfermedades(id_reporte_enfermedades);
                listaenf.add(enfermedades);
                System.out.println("fecha_inicio: " + fecha_inicio);
                System.out.println("fecha_final: " + fecha_final);
                System.out.println("afectacion_produccion: " + afectacion_produccion);
                System.out.println("nombre_enfermedades: " + nombre_enfermedades);
                System.out.println("id_reporte_enfermedades: " + id_reporte_enfermedades);
                System.out.println("-----------------");
            }
            resultSet.close();
            statement.close();
            conn.close();
        } catch (Exception e) {
             e.printStackTrace();
            System.out.println("Error al ejecutar la consulta SELECT.");
            // TODO: handle exception
        }
        return listaenf;
    }
    public int insertEnfermedades(Enfermedades enfermedades) {
        try {
            Connection conn = DriverManager.getConnection(Conexionurl.url, Conexionurl.usuario, Conexionurl.contrasena);
            String query = "INSERT INTO enfermedades(fecha_inicio,fecha_final,afectacion_produccion,nombre_enfermedad) VALUES(?,?,?,?)";
            PreparedStatement statement = conn.prepareStatement(query);
            statement.setString(1, enfermedades.getFecha_Inicio());
            statement.setString(2, enfermedades.getFecha_Final());
            statement.setInt(3, enfermedades.getAfectacionProduccion());
            statement.setString(4, enfermedades.getNombre_Enfermedad());
            statement.executeUpdate();
            System.out.println("fecha_inicio: " + enfermedades.getFecha_Inicio());
            System.out.println("fecha_final: " + enfermedades.getFecha_Final());
            System.out.println("afectacion_produccion: " + enfermedades.getAfectacionProduccion());
            System.out.println("nombre_enfermedades: " + enfermedades.getNombre_Enfermedad());
            System.out.println("Inserción Exitosa");
            statement.close();
            conn.close();
            return 1;
        } catch (Exception e) {
            System.out.println("Error al ejecutar la consulta INSERT");
            e.printStackTrace();
            // TODO: handle exception
            return 0;
        }
    
    }
    public int updateEnfermedades(Enfermedades enfermedades) {
        try {
           Connection conn = DriverManager.getConnection(Conexionurl.url, Conexionurl.usuario, Conexionurl.contrasena);
           String query = "UPDATE enfermedades SET fecha_inicio = ?, fecha_final = ?, afectacion_produccion = ?, nombre_enfermedad = ? WHERE id_reporte_enfermedades = ?";
           PreparedStatement statement = conn.prepareStatement(query);
           statement.setString(1, enfermedades.getFecha_Inicio());
           statement.setString(2, enfermedades.getFecha_Final());
           statement.setInt(3, enfermedades.getAfectacionProduccion());
           statement.setString(4, enfermedades.getNombre_Enfermedad());
           statement.setInt(5, enfermedades.getId_Reporte_Enfermedades());
           int filas = statement.executeUpdate();
           if(filas > 0){
            System.out.println("fecha_inicio: " + enfermedades.getFecha_Inicio());
            System.out.println("fecha_final: " + enfermedades.getFecha_Final());
            System.out.println("afectacion_produccion: " + enfermedades.getAfectacionProduccion());
            System.out.println("nombre_enfermedades: " + enfermedades.getNombre_Enfermedad());
            System.out.println("id_reporte_enfermedades: " + enfermedades.getId_Reporte_Enfermedades());
            System.out.println("-----------------");
            System.out.println("Actualización Exitosa");
           }
           else{
            System.out.println("No se encontraron registros a actualizar");
           }
            statement.close();
            conn.close();
        } catch (Exception e) {
            e.printStackTrace();
            System.out.println("Error al ejecutar la consulta UPDATE");
            // TODO: handle exception
        }
        return 1;
    }
    public void deleteEnfermedades(Enfermedades enfermedades, int idenf) {
        String query = "DELETE FROM enfermedades WHERE id_reporte_enfermedades = " + idenf;
        try{
            Connection conn = DriverManager.getConnection(Conexionurl.url, Conexionurl.usuario, Conexionurl.contrasena);
            PreparedStatement statement = conn.prepareStatement(query);
            statement.executeUpdate();
            System.out.println("Eliminación Exitosa de Usuario");
            System.out.println("---------------");
            statement.close();
            conn.close();
        }
        catch (Exception e) {
            e.printStackTrace();
            System.out.println("Error al ejecutar la consulta DELETE");
        }
    }
    public static void main(String[] args) {
        Enfermedades enfermedades = new Enfermedades("2022/05/20","2022/06/20",1,"enfermedad1");
        EnfermedadesDAO enfermedadesDAO = new EnfermedadesDAO();
        enfermedadesDAO.insertEnfermedades(enfermedades);
        enfermedadesDAO.selectEnfermedades();
    }
}

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Controlador;
import java.awt.JobAttributes;
// IMPORTACIONES NECESARIAS
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import Modelo.*;
import Vista.*;
import java.util.ArrayList;
import java.util.List;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;
import javax.swing.JOptionPane;
import javax.swing.ListSelectionModel;

public class Controlador implements ActionListener{
    Cana_de_azucar canadeazucar = new Cana_de_azucar();
    CanadeAzucarDAO canadeazucardao = new CanadeAzucarDAO();
    Enfermedades enfermedades = new Enfermedades();
    EnfermedadesDAO enfdao = new EnfermedadesDAO();
    Productor_de_panela productor = new Productor_de_panela();
    ProductorDAO pdao = new ProductorDAO();
    Inside inside = new Inside();
    DefaultTableModel modelo = new DefaultTableModel();
    // isteners para detectar el click
    public Controlador(Inside vista){
        this.inside = vista;
        this.inside.jButtonSeleccionar.addActionListener(this);
        this.inside.jButtonInsertar.addActionListener(this);
        this.inside.jButtonSeleccionar1.addActionListener(this);
        this.inside.jButtonSeleccionar2.addActionListener(this);
        this.inside.jButtonInsertar1.addActionListener(this);
        this.inside.jButtonInsertar2.addActionListener(this);
        this.inside.jButtonSeleccionarFila.addActionListener(this);
        this.inside.jButtonSeleccionarFila1.addActionListener(this);
        this.inside.jButtonSeleccionarFila2.addActionListener(this);
        this.inside.jButtonActualizar.addActionListener(this);
        this.inside.jButtonActualizar1.addActionListener(this);
        this.inside.jButtonActualizar2.addActionListener(this);
        this.inside.jButtonSeleccionar2.addActionListener(this);
        this.inside.jButtonEliminar.addActionListener(this);
        this.inside.jButtonEliminar1.addActionListener(this);
        this.inside.jButtonEliminar2.addActionListener(this);
        listarCda(inside.jTableCdA);
        listarEnf(inside.jTable2);
        listaPdp(inside.jTable3);
    }
    // Aqui condicionales para indicar que accion usar
    @Override
    public void actionPerformed(ActionEvent e) {
       if(e.getSource() == inside.jButtonSeleccionar){
        listarCda(inside.jTableCdA);
    }
    else if(e.getSource() == inside.jButtonSeleccionar1){
        listarEnf(inside.jTable2);
    }
    else if(e.getSource() == inside.jButtonSeleccionar2){
         listarEnf(inside.jTable2);
    }
    else if(e.getSource() == inside.jButtonInsertar){
        InsertarCdA();
        listarCda(inside.jTableCdA);
    }
    else if(e.getSource() == inside.jButtonInsertar1){
        InsertarEnF();
        listarEnf(inside.jTable2);
    }
    else if(e.getSource() == inside.jButtonInsertar2){
        InsertarPdP();
        listarEnf(inside.jTable2);
    }
    else if(e.getSource() == inside.jButtonSeleccionarFila){
        escogerFilaCdA();
    }
    else if(e.getSource() == inside.jButtonSeleccionarFila1){
        escogerFilaEnf();
    }
    else if(e.getSource() == inside.jButtonSeleccionarFila2){
        escogerFilaPdp();
    }
    else if(e.getSource() == inside.jButtonActualizar1){
        actualizarEnf();
        listarEnf(inside.jTable2);
    }
    else if(e.getSource() == inside.jButtonActualizar){
        actualizarCdA();
        listarCda(inside.jTableCdA);
    }
    else if(e.getSource() == inside.jButtonActualizar2){
        actualizarPdp();
        listaPdp(inside.jTable3);
    }
    else if (e.getSource() == inside.jButtonEliminar){
       eliminarCda();
       listarCda(inside.jTableCdA);
    }
    else if(e.getSource() == inside.jButtonEliminar1){
        eliminarEnf();
        listarEnf(inside.jTable2);
    }
    else if(e.getSource() == inside.jButtonEliminar2){
        eliminarPdp();
        listaPdp(inside.jTable3);
    }
    }
    // Acciones CRUD
   

    public void listarCda(JTable JTableCdA){
        modelo = (DefaultTableModel)JTableCdA.getModel();
        modelo.setRowCount(0);
        List<Cana_de_azucar> listaCana = canadeazucardao.selectCana();
        Object[] objetocaña = new Object[4];
        for(int i = 0; i < listaCana.size(); i++){
            objetocaña[0] = listaCana.get(i).getProducido();
            objetocaña[1] = listaCana.get(i).getVariedad_de_cana();
            objetocaña[2] = listaCana.get(i).getToneladas_exportadas();
            objetocaña[3] = listaCana.get(i).getIdcana();
            modelo.addRow(objetocaña);
        }
        inside.jTableCdA.setModel(modelo);
    }
    public void listaPdp(JTable jTable3){
        modelo = (DefaultTableModel)jTable3.getModel();
        modelo.setRowCount(0);
        List<Productor_de_panela> listaPdp = pdao.selectProductor();
        Object[] objetopdp = new Object[3];
        for(int i = 0; i < listaPdp.size(); i++){
            objetopdp[0] = listaPdp.get(i).getNombre_ingenio();
            objetopdp[1] = listaPdp.get(i).getidPanela();
            objetopdp[2] = listaPdp.get(i).getCalidad_panela();
            modelo.addRow(objetopdp);
        }
        inside.jTable3.setModel(modelo);
    }
    public void listarEnf(JTable JTable2){
        modelo = (DefaultTableModel)JTable2.getModel();
        modelo.setRowCount(0);
        List<Enfermedades> listaEnf = enfdao.selectEnfermedades();
        Object[] objetoenf = new Object[5];
        for(int i = 0; i < listaEnf.size(); i++){
            objetoenf[0] = listaEnf.get(i).getFecha_Inicio();
            objetoenf[1] = listaEnf.get(i).getFecha_Final();
            objetoenf[2] = listaEnf.get(i).getAfectacionProduccion();
            objetoenf[3] = listaEnf.get(i).getNombre_Enfermedad();
            objetoenf[4] = listaEnf.get(i).getId_Reporte_Enfermedades();
            modelo.addRow(objetoenf);
        }
        inside.jTable2.setModel(modelo);
    }
    public void InsertarCdA(){
        String variedad_de_cana = inside.jTextFieldvariedaddecaña.getText();
        String toneladas_exportadas= inside.jTextFieldTexp.getText();
        Cana_de_azucar CdA = new Cana_de_azucar();
        CanadeAzucarDAO cdao = new CanadeAzucarDAO();
        try{
            int producido = Integer.parseInt(inside.jTextFieldproducido.getText());
            CdA.setProducido(producido);
        }catch(NumberFormatException e){
             JOptionPane.showMessageDialog(inside, "Error. Use Numeros");
        }
        
        CdA.setVariedad_de_cana(variedad_de_cana);
        CdA.setToneladas_exportadas(toneladas_exportadas);
        int solicitud = cdao.insertCana(CdA);
        if(solicitud == 1){
            JOptionPane.showMessageDialog(inside, "Registro insertado");
        }else{
            JOptionPane.showMessageDialog(inside, "Error al insertar");
        }
 
    }
    public void InsertarEnF(){
        String fecha_inicio = inside.jTextFieldfinicio.getText();
        String fecha_final =inside.jTextFieldffinal.getText();
        String nombre_enfermedad = inside.jTextFieldnenf.getText();
        Enfermedades EnF = new  Enfermedades();
        EnfermedadesDAO  edao = new EnfermedadesDAO();
        EnF.setFecha_Inicio(fecha_inicio);
        EnF.setFecha_Final(fecha_final);
        try{
        int afectaccion_produccion = Integer.parseInt(inside.jTextFieldfadp.getText());
        EnF.setAfectacion_Produccion(afectaccion_produccion);
        }
        catch(NumberFormatException e){
        JOptionPane.showMessageDialog(inside, "Error, Use numeros");
        }
        
        EnF.setNombre_Enfermedad(nombre_enfermedad);
        int solicitud = edao.insertEnfermedades(EnF);
        if (solicitud == 1){
            JOptionPane.showMessageDialog(inside, "registro insertado con exito");
        }
        else{
            JOptionPane.showMessageDialog(inside, "error al insertar ");
        }
        }
 public void InsertarPdP(){
    String nombre_ingenio = inside.jTextFieldningenio.getText();
    String calidad_panela =inside.jComboBoxcdp.getSelectedItem().toString();
    Productor_de_panela PdP = new Productor_de_panela ();
    ProductorDAO pdao = new ProductorDAO();
    PdP.setNombre_ingenio(nombre_ingenio);
    PdP.setCalidad_panela(calidad_panela);
    int solicitud = pdao.insertProductor_de_panela(PdP);
    if(solicitud== 1){
        JOptionPane.showMessageDialog(inside, "registro insertado con exito");
    }else{
        JOptionPane.showMessageDialog(inside, "registro fallido");
    }
   }
   public void escogerFilaCdA(){
       int fila = inside.jTableCdA.getSelectedRow();
       if(fila < 0){
           JOptionPane.showMessageDialog(inside, "Seleccione la fila");
       }
       else{
           int producido = Integer.parseInt(inside.jTableCdA.getValueAt(fila,0).toString());
           String variedad_de_cana = inside.jTableCdA.getValueAt(fila,1).toString();
           String toneladas_exportadas = inside.jTableCdA.getValueAt(fila,2).toString();
           int idcana = Integer.parseInt(inside.jTableCdA.getValueAt(fila, 3).toString());
           inside.jTextFieldproducido.setText(String.valueOf(producido));
           inside.jTextFieldvariedaddecaña.setText(variedad_de_cana);
           inside.jTextFieldTexp.setText(toneladas_exportadas);
           inside.jTextFieldidcaña.setText(String.valueOf(idcana));
       }
   }
    public void actualizarCdA(){
        int producido = Integer.parseInt(inside.jTextFieldproducido.getText());
        String variedad_de_cana = inside.jTextFieldvariedaddecaña.getText();
        String toneladas_exportadas= inside.jTextFieldTexp.getText();
        int idcana = Integer.parseInt(inside.jTextFieldidcaña.getText());
        canadeazucar.setProducido(producido);
        canadeazucar.setVariedad_de_cana(variedad_de_cana);
        canadeazucar.setToneladas_exportadas(toneladas_exportadas);
        canadeazucar.setIdcana(idcana);
        int r = canadeazucardao.updateCana(canadeazucar);
        if (r == 1){
            JOptionPane.showMessageDialog(inside,"Actualizacion Exitosa");
        }else{
            JOptionPane.showMessageDialog(inside, "Actualizacion Fallida");
        }
        
    }
    public void escogerFilaEnf(){
        int fila = inside.jTable2.getSelectedRow();
        if(fila < 0){
            JOptionPane.showMessageDialog(inside, "Seleccione la fila");
        }else{
            String fecha_inicio = inside.jTable2.getValueAt(fila, 0).toString();
            String fecha_final = inside.jTable2.getValueAt(fila, 1).toString();
            int afectaccion_produccion = Integer.parseInt(inside.jTable2.getValueAt(fila,2).toString());
            String nombre_enfermedades = inside.jTable2.getValueAt(fila, 3).toString();
            int id_reporte_enfermedades = Integer.parseInt(inside.jTable2.getValueAt(fila, 4).toString());
            inside.jTextFieldfinicio.setText(fecha_inicio);
            inside.jTextFieldffinal.setText(fecha_final);
            inside.jTextFieldfadp.setText(String.valueOf(afectaccion_produccion));
            inside.jTextFieldnenf.setText(nombre_enfermedades);
            inside.jTextFieldidreportes.setText(String.valueOf(id_reporte_enfermedades));
        }
    }
    public void actualizarEnf(){
        String fecha_inicio = inside.jTextFieldfinicio.getText();
        String fecha_final =inside.jTextFieldffinal.getText();
        int afectacion_produccion = Integer.parseInt(inside.jTextFieldfadp.getText());
        String nombre_enfermedad = inside.jTextFieldnenf.getText();
        int id_reporte_enfermedades = Integer.parseInt(inside.jTextFieldidreportes.getText());
        enfermedades.setFecha_Inicio(fecha_inicio);
        enfermedades.setFecha_Final(fecha_final);
        enfermedades.setAfectacion_Produccion(afectacion_produccion);
        enfermedades.setNombre_Enfermedad(nombre_enfermedad);
        enfermedades.setId_Reporte_Enfermedades(id_reporte_enfermedades);
        int respuesta = enfdao.updateEnfermedades(enfermedades);
        if (respuesta == 1){
            JOptionPane.showMessageDialog(inside, "Actualizacion Exitosa");
        }
        else{
            JOptionPane.showMessageDialog(inside, "Actualizacion Fallida");
        }
    }
    public void escogerFilaPdp(){
        int fila = inside.jTable3.getSelectedRow();
        if (fila < 0){
            JOptionPane.showMessageDialog(inside, "Escoge una fila ");
        }
        else{
            String nombre_ingenio = inside.jTable3.getValueAt(fila, 0).toString();
            int idpanela = Integer.parseInt(inside.jTable3.getValueAt(fila, 1).toString());
            String calidad_panela = inside.jTable3.getValueAt(fila, 2).toString();
            inside.jTextFieldningenio.setText(nombre_ingenio);
            inside.jTextFieldidpanela.setText(String.valueOf(idpanela));
            inside.jComboBoxcdp.setSelectedItem(calidad_panela);
        }
    }
    public void actualizarPdp(){
        String nombre_ingenio = inside.jTextFieldningenio.getText();
        int idpanela = Integer.parseInt(inside.jTextFieldidpanela.getText());
        String calidad_panela = inside.jComboBoxcdp.getSelectedItem().toString();
        productor.setNombre_ingenio(nombre_ingenio);
        productor.setIdPanela(idpanela);
        productor.setCalidad_panela(calidad_panela);
        int respuesta = pdao.updateProductor_de_panela(productor);
        if (respuesta == 1){
            JOptionPane.showMessageDialog(inside, "Actualizacion Exitosa");
        }
        else{
            JOptionPane.showMessageDialog(inside, "Actualizacion Fallida");
        }

    }
   
    public void eliminarCda(){
        int fila = inside.jTableCdA.getSelectedRow();
        if (fila < 0){
            JOptionPane.showMessageDialog(inside, "Seleccione la fila");
        }
        else{
          int idcana = Integer.parseInt(inside.jTableCdA.getValueAt(fila, 3).toString());
          canadeazucardao.deleteCana(canadeazucar, idcana);
          JOptionPane.showMessageDialog(inside, "Fila Eliminada");
        }
    }
    public void eliminarEnf(){
        int fila = inside.jTable2.getSelectedRow();
        if(fila < 0){
            JOptionPane.showMessageDialog(inside, "Seleccione la fila");
        }else{
            int idr = Integer.parseInt(inside.jTable2.getValueAt(fila, 4).toString());
            enfdao.deleteEnfermedades(enfermedades, idr);
            JOptionPane.showMessageDialog(inside, "Fila eliminada");
            
        }
    }
    public void eliminarPdp(){
        int fila = inside.jTable3.getSelectedRow();
        if(fila < 0){
            JOptionPane.showMessageDialog(inside, "Seleccione la fila");
        }else{
            int idpan = Integer.parseInt(inside.jTable3.getValueAt(fila, 1).toString());
            pdao.deleteProductor_de_panela(productor, idpan);
            JOptionPane.showMessageDialog(inside, "Fila eliminada");
        }
    }
   
  
  }
  
   
   

